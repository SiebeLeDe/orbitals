""" Module that tests (with pytest) the most high-level functionality of the package, being the CalcAnalyzer class."""
import pathlib as pl
import pytest
from orb_analysis.complex import FACalcAnalyser, create_calc_analyser

current_dir = pl.Path(__file__).parent
fixtures_dir = current_dir / "fixtures" / "rkfs"


@pytest.fixture()
def calc_analyzer_restricted_nocore_fragsym_c3v() -> FACalcAnalyser:
    """Returns a CalcAnalyzer instance."""
    rkf_path = fixtures_dir / 'restricted_nocore_fragsym_c3v_full.adf.rkf'
    return create_calc_analyser(rkf_path)


@pytest.fixture()
def calc_analyzer_restricted_largecore_fragsym_c3v() -> FACalcAnalyser:
    """Returns a CalcAnalyzer instance."""
    rkf_path = fixtures_dir / 'restricted_largecore_fragsym_c3v_full.adf.rkf'
    return create_calc_analyser(rkf_path)


@pytest.fixture()
def calc_analyzer_restricted_nocore_fragsym_nosym() -> FACalcAnalyser:
    """Returns a CalcAnalyzer instance."""
    rkf_path = fixtures_dir / 'restricted_nocore_fragsym_nosym_full.adf.rkf'
    return create_calc_analyser(rkf_path)


# ------------------------------------------------------------
# ------------------Orbital energy tests----------------------
# ------------------------------------------------------------
#
# The following tests are for the get_orbital_energy method for various types of calculations.
# These include: restricted_nocore_fragsym_c3v, restricted_largecore_fragsym_c3v, restricted_nocore_fragsym_nosym
#

def test_get_orbital_energy_restricted_nocore_fragsym_c3v(calc_analyzer_restricted_nocore_fragsym_c3v):
    """ Tests the `get_orbital_energy` method for a restricted, no frozen core, fragment symmetry, c3v complex symmetry calculation ."""
    analyzer = calc_analyzer_restricted_nocore_fragsym_c3v
    frag1_energy = analyzer.get_orbital_energy(1, "8_A1")
    frag2_energy = analyzer.get_orbital_energy(2, "7_A1")
    assert frag1_energy == pytest.approx(-0.240836, abs=1e-3)
    assert frag2_energy == pytest.approx(-0.419846, abs=1e-3)


def test_get_orbital_energy_restricted_nocore_fragsym_c3v_degenerate(calc_analyzer_restricted_nocore_fragsym_c3v):
    """ Tests the `get_orbital_energy` method for a restricted, no frozen core, fragment symmetry, c3v complex symmetry calculation ."""
    analyzer = calc_analyzer_restricted_nocore_fragsym_c3v
    frag1_energy = analyzer.get_orbital_energy(1, "5_E1:1")
    frag2_energy = analyzer.get_orbital_energy(2, "5_E1:1")
    assert frag1_energy == pytest.approx(-0.331981, abs=1e-3)
    assert frag2_energy == pytest.approx(-0.266067, abs=1e-3)


def test_get_orbital_energy_restricted_largecore_fragsym_c3v(calc_analyzer_restricted_largecore_fragsym_c3v):
    """ Tests the `get_orbital_energy` method for a restricted, large frozen core, fragment symmetry, c3v complex symmetry calculation ."""
    analyzer = calc_analyzer_restricted_largecore_fragsym_c3v
    frag1_energy = analyzer.get_orbital_energy(1, "2_A1")
    frag2_energy = analyzer.get_orbital_energy(2, "2_A1")
    assert frag1_energy == pytest.approx(-0.238999, abs=1e-3)
    assert frag2_energy == pytest.approx(-0.105255, abs=1e-3)


def test_get_orbital_energy_restricted_largecore_fragsym_c3v_degenerate(calc_analyzer_restricted_largecore_fragsym_c3v):
    """ Tests the `get_orbital_energy` method for a restricted, large frozen core, fragment symmetry, c3v complex symmetry calculation ."""
    analyzer = calc_analyzer_restricted_largecore_fragsym_c3v
    frag1_energy = analyzer.get_orbital_energy(1, "1_E1:1")
    frag2_energy = analyzer.get_orbital_energy(2, "1_E1:1")
    assert frag1_energy == pytest.approx(-0.332368, abs=1e-3)
    assert frag2_energy == pytest.approx(-0.265912, abs=1e-3)


# ------------------------------------------------------------
# ------------------Gross population tests--------------------
# ------------------------------------------------------------

def test_get_gross_population_restricted_nocore_fragsym_c3v(calc_analyzer_restricted_nocore_fragsym_c3v):
    """ Tests the `get_gross_population` method for a restricted, no frozen core, fragment symmetry, c3v complex symmetry calculation ."""
    analyzer = calc_analyzer_restricted_nocore_fragsym_c3v
    frag1_pop = analyzer.get_gross_population(1, "8_A1")
    frag2_pop = analyzer.get_gross_population(2, "8_A1")
    assert frag1_pop == pytest.approx(1.738, abs=1e-3)
    assert frag2_pop == pytest.approx(0.258, abs=1e-3)


def test_get_gross_population_restricted_nocore_fragsym_c3v_degenerate(calc_analyzer_restricted_nocore_fragsym_c3v):
    """ Tests the `get_gross_population` method for a restricted, no frozen core, fragment symmetry, c3v complex symmetry calculation ."""
    analyzer = calc_analyzer_restricted_nocore_fragsym_c3v
    frag1_pop = analyzer.get_gross_population(1, "5_E1:1")
    frag2_pop = analyzer.get_gross_population(2, "5_E1:1")
    assert frag1_pop == pytest.approx(1.993, abs=1e-3)
    assert frag2_pop == pytest.approx(1.966, abs=1e-3)


def test_get_gross_population_restricted_largecore_fragsym_c3v(calc_analyzer_restricted_largecore_fragsym_c3v):
    """ Tests the `get_gross_population` method for a restricted, large frozen core, fragment symmetry, c3v complex symmetry calculation."""
    analyzer = calc_analyzer_restricted_largecore_fragsym_c3v
    frag1_pop = analyzer.get_gross_population(1, "2_A1")
    frag2_pop = analyzer.get_gross_population(2, "2_A1")
    assert frag1_pop == pytest.approx(1.718, abs=1e-3)
    assert frag2_pop == pytest.approx(0.268, abs=1e-3)


def test_get_gross_population_restricted_largecore_fragsym_c3v_degenerate(calc_analyzer_restricted_largecore_fragsym_c3v):
    """ Tests the `get_gross_population` method for a restricted, large frozen core, fragment symmetry, c3v complex symmetry calculation."""
    analyzer = calc_analyzer_restricted_largecore_fragsym_c3v
    frag1_pop_1 = analyzer.get_gross_population(1, "1_E1:1")
    frag1_pop_2 = analyzer.get_gross_population(1, "1_E1:2")
    frag2_pop_1 = analyzer.get_gross_population(2, "1_E1:1")
    frag2_pop_2 = analyzer.get_gross_population(2, "1_E1:2")
    assert frag1_pop_1 == pytest.approx(frag1_pop_2, abs=1e-3)
    assert frag2_pop_1 == pytest.approx(frag2_pop_2, abs=1e-3)
    assert frag1_pop_1 == pytest.approx(1.994, abs=1e-3)
    assert frag2_pop_1 == pytest.approx(1.970, abs=1e-3)

# ------------------------------------------------------------
# ---------------------Overlap tests--------------------------
# ------------------------------------------------------------


def test_get_overlap_restricted_nocore_fragsym_c3v(calc_analyzer_restricted_nocore_fragsym_c3v):
    """ Tests the `get_overlap` method for a restricted, no frozen core, fragment symmetry, c3v complex symmetry calculation."""
    analyzer = calc_analyzer_restricted_nocore_fragsym_c3v
    homo_lumo_overlap = analyzer.get_overlap("8_A1", "8_A1")
    homo_homo_overlap = analyzer.get_overlap("8_A1", "7_A1")
    assert homo_lumo_overlap == pytest.approx(0.3958, abs=1e-3)
    assert homo_homo_overlap == pytest.approx(0.2511, abs=1e-3)


def test_get_et_overlap_restricted_nocore_fragsym_c3v(calc_analyzer_restricted_largecore_fragsym_c3v):
    """ Tests the `get_overlap` method for a restricted, no frozen core, fragment symmetry, c3v complex symmetry calculation."""
    analyzer = calc_analyzer_restricted_largecore_fragsym_c3v
    homo_lumo_overlap = analyzer.get_overlap("2_A1", "2_A1")
    homo_homo_overlap = analyzer.get_overlap("2_A1", "1_A1")
    assert homo_lumo_overlap == pytest.approx(0.4007, abs=1e-3)
    assert homo_homo_overlap == pytest.approx(0.2543, abs=1e-3)
