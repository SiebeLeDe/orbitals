"""
Module containing functions for extracting SFO data from the rkf files of fragment analysis calculations.
The following terms can be extracted form the rkf files:
- Overlap (in a.u.)
- Orbital Energy (in eV)
- Occupation (in a.u.)

"""
from __future__ import annotations
from scm.plams import KFFile
from typing import Callable, Sequence
import numpy as np
from orb_analysis.custom_types import Array1D

# --------------------Helper Function(s)-------------------- #


def split_1d_array_into_dict_sorted_by_symlabels(data_array: Array1D, symlabels: Sequence[str], ) -> dict[str, Array1D]:
    """
    Splits a 1D array into a dictionary of arrays based on the symlabels. The symlabels are the keys of the dictionary.
    data_array and symlabels must have the same length.
    """
    n_entries_per_symlabel = [symlabels.count(symlabel) for symlabel in set(symlabels)]
    data_ordered_by_symlabel = {symlabel: np.zeros(n_entries) for symlabel, n_entries in zip(set(symlabels), n_entries_per_symlabel)}

    # Now we loop over the symlabels and add the data to the right array
    sym_label_counter = {symlabel: 0 for symlabel in set(symlabels)}
    for data_entry, symlabel in zip(data_array, symlabels):
        data_ordered_by_symlabel[symlabel][sym_label_counter[symlabel]] = data_entry
        sym_label_counter[symlabel] += 1
    return data_ordered_by_symlabel

# --------------------Frozen Core Handling-------------------- #


def read_frozen_cores_per_irrep(kf_file: KFFile, symlabels_each_sfo: Sequence[str]) -> dict[str, int]:
    """
    Reads the number of frozen cores per irrep from the KFFile.

    The number of frozen cores per irrep is important for getting gross populations and overlap analysis.
    Basically, the SFO index shown in AMSLevels is different than the index shown in the overlap and population analysis because they can be shifted by frozen cores.

    The core works as follows: there are numbers for each irrep such as [4, 0, 1, 1] for irreps [A1, A2, E1, E2]
    The frozen cores are the *cumulative* sum of these numbers. So, for the above example, the frozen cores are [4, 4, 5, 6]
    But, if the occupation of an irrep is 0, then the frozen core is 0. So, for the above example, the frozen cores are [4, 0, 5, 6]

    Moreover, if the complex calculation uses symmetry, but the fragments themselves do not, then the "A" irrep is added, being the sum of all frozen cores.

    In case there is no frozen core and no symmetry, but the fragments use symmetry, then the frozen core is 0 for all irreps that are present in the fragments.
    """
    sym_labels_right_order = sorted(set(symlabels_each_sfo), key=symlabels_each_sfo.index)
    n_core_orbs: list[int] = kf_file.read("Symmetry", "ncbs", return_as_list=True)  # type: ignore since n_core_orbs is a list of ints

    n_frozen_cores_per_irrep_summed = {irrep: 0 for irrep in sym_labels_right_order}

    # Add the "A" irrep to the dictionary for the case when symmetry is not used (e.g. NoSym), but the fragments themselves use symmetry.
    # This is only used for the overlap analysis.
    n_frozen_cores_per_irrep_summed["A"] = sum(n_core_orbs)

    # This is the case when there are no frozen cores and without symmetry, but the fragments themselves use symmetry...
    if len(n_core_orbs) == 1 and n_core_orbs[0] == 0:
        return n_frozen_cores_per_irrep_summed | {irrep: 0 for irrep in sym_labels_right_order}

    # Now we have to sum the frozen cores for each irrep to get the cumulative sum
    frozen_core_sum = 0
    for n_core_one_irrep, sym_label in zip(n_core_orbs, sym_labels_right_order):
        # If there are no frozen cores for this irrep, we can skip it
        if n_core_one_irrep == 0:
            continue

        frozen_core_sum += n_core_one_irrep
        n_frozen_cores_per_irrep_summed[sym_label] = frozen_core_sum

    return n_frozen_cores_per_irrep_summed

# --------------------Restricted Property Function(s)-------------------- #


def read_restricted_gross_populations(kf_file: KFFile, section: str, variable: str) -> Array1D:
    """ Reads the gross populations from the KFFile. """
    gross_populations = np.array(kf_file.read(section, variable))  # type: ignore
    return gross_populations


def read_restricted_orbital_energies(kf_file: KFFile, section: str, variable: str) -> Array1D:
    """ Reads the orbital energies from the KFFile. """
    # escale refers energies scaled by relativistic effects (ZORA). If no relativistic effects are present, "energy" is the appropriate key.
    if property == "orb_energies" and ("SFOs", "escale") not in kf_file:
        variable = "energy"

    # Reads the orbital energies for both fragments and selects the data for the current fragment
    orb_energies = np.array(kf_file.read(section, variable))  # type: ignore

    return orb_energies


def read_restricted_occupations(kf_file: KFFile, section: str, variable: str) -> Array1D:
    """ Reads the occupations from the KFFile. """
    occupations = np.array(kf_file.read(section, variable))  # type: ignore
    return occupations


# --------------------Unrestricted Property Function(s)-------------------- #


# --------------------Property to Function Mapping-------------------- #


# Format: {property: (callable function for reading property, section in KFFile, variable in KFFile)}
RESTRICTED_KEY_FUNC_MAPPING: dict[str, tuple[Callable, str, str]] = {
    "orb_energies": (read_restricted_orbital_energies, "SFOs", "escale"),
    "occupations": (read_restricted_occupations, "SFOs", "occupation"),
}

# --------------------Interface Function(s)-------------------- #


def get_restricted_fragment_properties(kf_file: KFFile, sfo_indices_of_one_frag: Sequence[int], frag_symlabels_each_sfo: Sequence[str]) -> dict[str, dict[str, Array1D]]:
    """
    Returns a dictionary of dictionaries with the properties of the fragments.

    The properties are:
        - Orbital Energies
        - Occupations
    """
    data_dic_to_be_unpacked: dict[str, dict[str, Array1D]] = {}
    for property, (func, section, variable) in RESTRICTED_KEY_FUNC_MAPPING.items():

        data = func(kf_file, section, variable)

        data = np.array([data[i] for i in sfo_indices_of_one_frag])

        # Now we turn one long array into a dictionary of arrays sorted by symlabels (e.g. [.....] -> {"A1": [.....], "A2": [.....]})
        data_dic_to_be_unpacked[property] = split_1d_array_into_dict_sorted_by_symlabels(data_array=data, symlabels=frag_symlabels_each_sfo)

    return data_dic_to_be_unpacked


def get_gross_populations(kf_file: KFFile, n_frozen_cores_per_irrep, sfo_indices_of_one_frag: Sequence[int], frag_symlabels_each_sfo: Sequence[str]) -> dict[str, Array1D[np.float64]]:
    """
    Reads the gross populations from the KFFile by taking into account the frozen cores.
    Annoyingly, the "SFOs" sections contains the SFOs of both fragments that ALREADY HAVE BEEN FILTERED for the frozen cores.
    For example, the SFOs number may be 114, but the gross population array may have 148 entries. This is because the first 34 entries are the frozen cores.

    Therefore, the sum of `sfo_indices_of_one_frag` and `n_frozen_cores_per_irrep` is used to get the correct indices for SFOs on both fragments and all irreps.
    """
    gross_pop = read_restricted_gross_populations(kf_file, "SFO popul", "sfo_grosspop")
    [print(f"{i :4d}, {gross_pop :.3f}") for i, gross_pop in enumerate(gross_pop, 1)]
    gross_pop = split_1d_array_into_dict_sorted_by_symlabels(data_array=gross_pop, symlabels=frag_symlabels_each_sfo)
    gross_pop = {irrep: data[n_frozen_cores_per_irrep[irrep]:] for irrep, data in gross_pop.items()}
    return gross_pop
